import { useState, useEffect, useRef, useCallback } from "react";

/* ═══════════════════════════════════════════════════════════════
   GLOBAL STYLES — Palette: Deep Cosmos · Periwinkle · Warm Coral
═══════════════════════════════════════════════════════════════ */
const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=Outfit:wght@200;300;400;500;600;700&display=swap');

    *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }

    /* ── Colour tokens ── */
    :root {
      --indigo:     #6366f1;
      --indigo-lt:  #a5b4fc;
      --indigo-dk:  #4338ca;
      --teal:       #2dd4bf;
      --teal-lt:    #99f6e4;
      --coral:      #fb923c;
      --coral-lt:   #fdba74;
      --t: 0.55s cubic-bezier(.4,0,.2,1);
    }

    /* ── Dark theme ── */
    .dark {
      --bg:     #060b18;
      --bg2:    #0b1225;
      --bg3:    #101830;
      --surf:   rgba(99,102,241,0.055);
      --surf2:  rgba(255,255,255,0.07);
      --border: rgba(99,102,241,0.22);
      --text:   #c8d0e8;
      --muted:  #6272a4;
      --head:   #e8eeff;
      --acc:    #818cf8;
      --acc2:   #a5b4fc;
      --glow:   rgba(99,102,241,0.22);
      --shadow: rgba(0,0,10,0.75);
      --nav-bg: rgba(6,11,24,0.9);
      --orb1:   rgba(99,102,241,0.13);
      --orb2:   rgba(45,212,191,0.09);
    }

    /* ── Light theme ── */
    .light {
      --bg:     #f8f9ff;
      --bg2:    #eef0ff;
      --bg3:    #e2e5ff;
      --surf:   rgba(255,255,255,0.85);
      --surf2:  rgba(255,255,255,0.97);
      --border: rgba(79,70,229,0.18);
      --text:   #2d2f6b;
      --muted:  #6366a0;
      --head:   #1e1a4f;
      --acc:    #4f46e5;
      --acc2:   #6366f1;
      --glow:   rgba(79,70,229,0.12);
      --shadow: rgba(30,26,79,0.12);
      --nav-bg: rgba(248,249,255,0.94);
      --orb1:   rgba(99,102,241,0.09);
      --orb2:   rgba(45,212,191,0.07);
    }

    html { scroll-behavior:smooth; }
    body {
      font-family:'Outfit',sans-serif;
      background:var(--bg); color:var(--text);
      transition:background var(--t),color var(--t);
      overflow-x:hidden;
    }
    h1,h2,h3,h4 { font-family:'Cormorant Garamond',serif; color:var(--head); }

    ::-webkit-scrollbar{width:4px;}
    ::-webkit-scrollbar-track{background:var(--bg);}
    ::-webkit-scrollbar-thumb{background:var(--indigo);border-radius:10px;}

    /* ── Keyframes ── */
    @keyframes fadeUp    {from{opacity:0;transform:translateY(34px)}to{opacity:1;transform:none}}
    @keyframes fadeIn    {from{opacity:0}to{opacity:1}}
    @keyframes fadeLeft  {from{opacity:0;transform:translateX(-34px)}to{opacity:1;transform:none}}
    @keyframes fadeRight {from{opacity:0;transform:translateX(34px)}to{opacity:1;transform:none}}
    @keyframes float     {0%,100%{transform:translateY(0) rotate(-1deg)}50%{transform:translateY(-16px) rotate(1deg)}}
    @keyframes spin      {to{transform:rotate(360deg)}}
    @keyframes rotateSlow{to{transform:rotate(360deg)}}
    @keyframes shimmer   {0%{background-position:-200% 0}100%{background-position:200% 0}}
    @keyframes orb1      {0%,100%{transform:translate(0,0) scale(1)}33%{transform:translate(60px,-40px) scale(1.15)}66%{transform:translate(-20px,30px) scale(0.9)}}
    @keyframes orb2      {0%,100%{transform:translate(0,0) scale(1)}33%{transform:translate(-50px,20px) scale(1.1)}66%{transform:translate(30px,-25px) scale(0.95)}}
    @keyframes orb3      {0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(25px,45px) scale(1.08)}}
    @keyframes pulse     {0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.07);opacity:.9}}
    @keyframes heartbeat {0%,100%{transform:scale(1)}14%{transform:scale(1.4)}28%{transform:scale(1)}42%{transform:scale(1.2)}}
    @keyframes slideModal{from{opacity:0;transform:scale(.88) translateY(24px)}to{opacity:1;transform:none}}
    @keyframes twinkle   {0%,100%{opacity:.1;transform:scale(.5)}50%{opacity:1;transform:scale(1.4)}}
    @keyframes confetti  {0%{transform:translateY(-10px) rotate(0deg);opacity:1}100%{transform:translateY(100vh) rotate(720deg);opacity:0}}
    @keyframes borderGlow{0%,100%{box-shadow:0 0 8px var(--glow)}50%{box-shadow:0 0 32px var(--glow),0 0 64px rgba(99,102,241,.08)}}
    @keyframes petals    {0%{transform:translateY(-5vh) rotate(0deg) translateX(0);opacity:0}10%{opacity:.85}90%{opacity:.35}100%{transform:translateY(105vh) rotate(540deg) translateX(50px);opacity:0}}
    @keyframes aurora    {0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
    @keyframes sparkle   {0%,100%{opacity:0;transform:scale(0) rotate(0deg)}50%{opacity:1;transform:scale(1) rotate(180deg)}}
    @keyframes typewrite {from{width:0}to{width:100%}}
    @keyframes blinkCursor{0%,100%{border-right-color:var(--acc)}50%{border-right-color:transparent}}
    @keyframes ripple    {to{transform:scale(4);opacity:0}}
    @keyframes morphBlob {0%,100%{border-radius:60% 40% 30% 70%/60% 30% 70% 40%}50%{border-radius:30% 60% 70% 40%/50% 60% 30% 60%}}
    @keyframes slideUp   {from{transform:translateY(100%);opacity:0}to{transform:none;opacity:1}}
    @keyframes countUp   {from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
    @keyframes waveIn    {0%{transform:scaleX(0)}100%{transform:scaleX(1)}}
    @keyframes glow3d    {0%,100%{text-shadow:0 0 20px rgba(99,102,241,.4)}50%{text-shadow:0 0 40px rgba(99,102,241,.7),0 0 80px rgba(165,180,252,.3)}}
    @keyframes tiltIn    {from{opacity:0;transform:rotateX(-15deg) translateY(30px)}to{opacity:1;transform:rotateX(0) translateY(0)}}
    @keyframes particleFly{0%{transform:translateY(0) translateX(0) scale(1);opacity:1}100%{transform:translateY(-120px) translateX(var(--dx,30px)) scale(0);opacity:0}}
    @keyframes gradFlow  {0%{background-position:0% 0%}50%{background-position:100% 100%}100%{background-position:0% 0%}}

    /* ── Scroll reveal ── */
    .sr  {opacity:0;transform:translateY(28px);transition:opacity .9s cubic-bezier(.4,0,.2,1),transform .9s cubic-bezier(.4,0,.2,1);}
    .sr.vis{opacity:1;transform:none;}
    .sr-l{opacity:0;transform:translateX(-28px);transition:opacity .9s cubic-bezier(.4,0,.2,1),transform .9s cubic-bezier(.4,0,.2,1);}
    .sr-l.vis{opacity:1;transform:none;}
    .sr-r{opacity:0;transform:translateX(28px);transition:opacity .9s cubic-bezier(.4,0,.2,1),transform .9s cubic-bezier(.4,0,.2,1);}
    .sr-r.vis{opacity:1;transform:none;}
    .sr-scale{opacity:0;transform:scale(.88);transition:opacity .9s cubic-bezier(.4,0,.2,1),transform .9s cubic-bezier(.4,0,.2,1);}
    .sr-scale.vis{opacity:1;transform:scale(1);}

    /* ── Utility ── */
    .glass{background:var(--surf);backdrop-filter:blur(28px);-webkit-backdrop-filter:blur(28px);border:1px solid var(--border);box-shadow:0 8px 40px var(--shadow);}
    .indigo-txt{
      background:linear-gradient(135deg,var(--indigo-dk),var(--indigo),var(--indigo-lt),var(--teal),var(--indigo));
      background-size:240% auto;
      -webkit-background-clip:text;-webkit-text-fill-color:transparent;
      background-clip:text;animation:shimmer 4s linear infinite;
    }
    .container{max-width:1180px;margin:0 auto;padding:0 28px;}
    section{padding:108px 0;position:relative;overflow:hidden;}
    .sec-label{font-family:'Outfit',sans-serif;font-size:.7rem;letter-spacing:.26em;text-transform:uppercase;color:var(--muted);text-align:center;margin-bottom:10px;}
    .sec-title{font-size:clamp(2rem,5vw,3.4rem);font-weight:600;text-align:center;line-height:1.08;margin-bottom:14px;}
    .divider{width:60px;height:3px;background:linear-gradient(90deg,transparent,var(--indigo),var(--teal),transparent);margin:0 auto 58px;border-radius:4px;}
    .bg-dots{position:absolute;inset:0;background-image:radial-gradient(circle,var(--border) 1px,transparent 1px);background-size:38px 38px;opacity:.28;pointer-events:none;z-index:0;}

    /* ── Cards with 3D tilt effect ── */
    .card{
      background:var(--surf);border:1px solid var(--border);border-radius:22px;padding:30px;
      backdrop-filter:blur(18px);
      transition:transform .4s cubic-bezier(.4,0,.2,1),box-shadow .4s,border-color .4s;
      transform-style:preserve-3d;
      will-change:transform;
    }
    .card:hover{
      transform:translateY(-8px) perspective(600px) rotateX(2deg);
      box-shadow:0 24px 60px var(--glow),0 0 0 1px rgba(99,102,241,.15);
      border-color:var(--acc);
    }

    /* ── Buttons ── */
    .btn-primary{
      display:inline-flex;align-items:center;gap:10px;
      padding:14px 32px;border-radius:50px;
      background:linear-gradient(135deg,var(--indigo-dk),var(--indigo),var(--indigo-lt));
      background-size:200% 200%;
      color:#fff;font-family:'Outfit',sans-serif;font-weight:600;font-size:.94rem;letter-spacing:.04em;
      text-decoration:none;border:none;cursor:pointer;
      box-shadow:0 6px 30px rgba(99,102,241,.4);
      transition:transform .3s,box-shadow .3s,filter .3s,background-position .5s;
      position:relative;overflow:hidden;
      animation:gradFlow 4s ease infinite;
    }
    .btn-primary::after{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(255,255,255,.2),transparent);opacity:0;transition:opacity .3s;}
    .btn-primary:hover{transform:translateY(-5px);box-shadow:0 16px 48px rgba(99,102,241,.55);filter:brightness(1.1);}
    .btn-primary:hover::after{opacity:1;}
    .btn-primary:active::before{content:'';position:absolute;border-radius:50%;background:rgba(255,255,255,.3);width:10px;height:10px;animation:ripple .6s ease-out forwards;}

    .btn-out{
      display:inline-flex;align-items:center;gap:10px;
      padding:13px 30px;border-radius:50px;
      background:transparent;color:var(--acc);
      font-family:'Outfit',sans-serif;font-weight:500;font-size:.94rem;letter-spacing:.04em;
      text-decoration:none;border:1.5px solid var(--acc);cursor:pointer;
      transition:all .3s;position:relative;overflow:hidden;
    }
    .btn-out::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,var(--indigo),var(--teal));opacity:0;transition:opacity .3s;border-radius:50px;}
    .btn-out:hover{color:#fff;border-color:transparent;transform:translateY(-4px);box-shadow:0 10px 32px var(--glow);}
    .btn-out:hover::before{opacity:1;}
    .btn-out span{position:relative;z-index:1;}

    /* ── Nav ── */
    nav{position:fixed;top:0;left:0;right:0;z-index:900;padding:20px 0;transition:all .45s cubic-bezier(.4,0,.2,1);}
    nav.shrunk{padding:10px 0;background:var(--nav-bg);backdrop-filter:blur(32px);-webkit-backdrop-filter:blur(32px);border-bottom:1px solid var(--border);box-shadow:0 4px 32px var(--shadow);}
    .nav-link{color:var(--muted);text-decoration:none;font-size:.78rem;letter-spacing:.14em;text-transform:uppercase;font-weight:400;transition:color .3s;position:relative;}
    .nav-link::after{content:'';position:absolute;bottom:-4px;left:0;right:0;height:1.5px;background:linear-gradient(90deg,var(--indigo),var(--teal));transform:scaleX(0);transition:transform .35s cubic-bezier(.4,0,.2,1);border-radius:4px;}
    .nav-link:hover{color:var(--acc);}
    .nav-link:hover::after{transform:scaleX(1);}

    /* ── Theme toggle ── */
    .tog{width:52px;height:28px;border-radius:50px;background:var(--surf2);border:1px solid var(--border);position:relative;cursor:pointer;display:flex;align-items:center;padding:3px;}
    .tog-k{width:21px;height:21px;border-radius:50%;background:linear-gradient(135deg,var(--indigo-dk),var(--indigo));transition:transform .45s cubic-bezier(.4,0,.2,1);display:flex;align-items:center;justify-content:center;font-size:10px;box-shadow:0 2px 8px rgba(99,102,241,.4);}
    .dark .tog-k{transform:translateX(24px);}
    .light .tog-k{transform:translateX(0);}

    /* ── Scroll progress ── */
    .prog{position:fixed;top:0;left:0;z-index:9999;height:3px;background:linear-gradient(90deg,var(--indigo-dk),var(--indigo),var(--teal),var(--coral));box-shadow:0 0 12px rgba(99,102,241,.6);transition:width .1s linear;border-radius:0 2px 2px 0;}

    /* ── Profile ring ── */
    .p-wrap{position:relative;display:inline-block;}
    .r1{position:absolute;inset:-6px;border-radius:50%;background:conic-gradient(var(--indigo),var(--teal),var(--coral-lt),var(--indigo-lt),var(--indigo-dk),var(--indigo));animation:rotateSlow 7s linear infinite;z-index:-1;}
    .r2{position:absolute;inset:-13px;border-radius:50%;background:conic-gradient(transparent 25%,rgba(99,102,241,.35) 50%,transparent 75%);animation:rotateSlow 11s linear infinite reverse;z-index:-1;}
    .p-img{width:256px;height:256px;border-radius:50%;object-fit:cover;display:block;border:5px solid var(--bg);}

    /* ── Timeline ── */
    .tl{position:relative;padding-left:46px;}
    .tl::before{content:'';position:absolute;left:14px;top:8px;bottom:8px;width:2px;background:linear-gradient(to bottom,var(--indigo) 0%,var(--teal) 60%,rgba(99,102,241,.05) 100%);}
    .tl-item{position:relative;margin-bottom:34px;}
    .tl-dot{position:absolute;left:-46px;top:6px;width:28px;height:28px;border-radius:50%;background:var(--bg2);border:2px solid var(--indigo);display:flex;align-items:center;justify-content:center;box-shadow:0 0 16px rgba(99,102,241,.3);}
    .tl-in{width:12px;height:12px;border-radius:50%;background:linear-gradient(135deg,var(--indigo),var(--teal));}

    /* ── Gallery ── */
    .gal{position:relative;overflow:hidden;border-radius:22px;aspect-ratio:16/9;cursor:pointer;}
    .gal-s{position:absolute;inset:0;background-size:cover;background-position:center;opacity:0;transition:opacity 1s ease;}
    .gal-s.on{opacity:1;}

    /* ── Lightbox ── */
    .lb{position:fixed;inset:0;z-index:2000;background:rgba(4,5,20,.96);display:flex;align-items:center;justify-content:center;animation:fadeIn .3s;}
    .lb-i{max-width:90vw;max-height:88vh;border-radius:14px;border:1px solid var(--border);animation:slideModal .4s cubic-bezier(.4,0,.2,1);object-fit:contain;}

    /* ── Modal ── */
    .mo{position:fixed;inset:0;z-index:2000;background:rgba(4,5,20,.94);display:flex;align-items:center;justify-content:center;animation:fadeIn .3s;}
    .mo-box{width:min(820px,95vw);animation:slideModal .4s cubic-bezier(.4,0,.2,1);}

    /* ── WA Float ── */
    .wa{position:fixed;bottom:30px;right:30px;z-index:800;width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#25d366,#128c7e);display:flex;align-items:center;justify-content:center;box-shadow:0 6px 28px rgba(37,211,102,.42);cursor:pointer;border:none;text-decoration:none;animation:pulse 2.2s ease-in-out infinite;transition:transform .3s;}
    .wa:hover{transform:scale(1.14);animation:none;}

    /* ── Tags ── */
    .tag{display:inline-block;padding:5px 16px;border-radius:50px;background:var(--surf2);border:1px solid var(--border);font-size:.76rem;color:var(--muted);font-weight:300;letter-spacing:.03em;transition:all .25s;}
    .tag.i{background:rgba(99,102,241,.1);border-color:rgba(99,102,241,.34);color:var(--acc);transition:all .25s;}
    .tag.i:hover{background:rgba(99,102,241,.2);transform:translateY(-2px);}
    .tag.t{background:rgba(45,212,191,.1);border-color:rgba(45,212,191,.3);color:var(--teal);}

    /* ── Heart ── */
    .heart{display:inline-block;animation:heartbeat 1.6s ease-in-out infinite;}

    /* ── Corners ── */
    .cd{position:absolute;width:66px;height:66px;border-color:rgba(99,102,241,.4);border-style:solid;opacity:.6;}
    .ctl{top:18px;left:18px;border-width:2px 0 0 2px;}
    .ctr{top:18px;right:18px;border-width:2px 2px 0 0;}
    .cbl{bottom:18px;left:18px;border-width:0 0 2px 2px;}
    .cbr{bottom:18px;right:18px;border-width:0 2px 2px 0;}

    /* ── Loading ── */
    .loading{position:fixed;inset:0;z-index:9999;background:var(--bg);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:18px;transition:opacity .8s,visibility .8s;}
    .loading.gone{opacity:0;visibility:hidden;}
    .l-ring{width:68px;height:68px;border-radius:50%;border:3px solid var(--border);border-top-color:var(--indigo);border-right-color:var(--teal);animation:spin 1s linear infinite;}

    /* ── Gate ── */
    .petal{position:fixed;pointer-events:none;font-size:1.2rem;animation:petals var(--dur,6s) ease-in var(--del,0s) infinite;}
    .gate{position:fixed;inset:0;z-index:10000;overflow:hidden;display:flex;align-items:center;justify-content:center;}
    .gate-bg{
      position:absolute;inset:0;
      background:radial-gradient(ellipse at 30% 40%,#0f0a2e 0%,#080520 50%,#030212 100%);
    }
    .gate-aurora{
      position:absolute;inset:0;
      background:linear-gradient(135deg,rgba(99,102,241,.15) 0%,rgba(45,212,191,.08) 30%,rgba(251,146,60,.06) 60%,rgba(99,102,241,.12) 100%);
      background-size:400% 400%;
      animation:aurora 8s ease infinite;
    }
    .gate-card{position:relative;z-index:2;text-align:center;padding:clamp(38px,5.5vw,68px) clamp(30px,5vw,76px);max-width:min(620px,92vw);}
    .gate-title{font-size:clamp(1.6rem,4.5vw,3rem);font-weight:700;line-height:1.2;color:#e8eeff;margin-bottom:14px;font-family:'Cormorant Garamond',serif;}
    .gate-sub{font-size:clamp(.84rem,1.8vw,1rem);color:#6272a4;font-weight:300;margin-bottom:46px;line-height:1.8;}
    .gate-emoji{font-size:clamp(2.8rem,5.5vw,4.6rem);margin-bottom:22px;display:block;animation:float 3s ease-in-out infinite;}
    .no-btn{position:fixed;padding:13px 32px;border-radius:50px;background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.15);color:#7785c0;font-family:'Outfit',sans-serif;font-weight:500;font-size:.92rem;cursor:pointer;backdrop-filter:blur(8px);user-select:none;z-index:10001;transition:border-color .2s,transform .15s;}
    .no-btn:hover{border-color:rgba(99,102,241,.4);transform:rotate(-3deg);}
    .yes-btn{padding:15px 44px;border-radius:50px;background:linear-gradient(135deg,#4338ca,#6366f1,#818cf8,#2dd4bf);background-size:200% 200%;color:#fff;font-family:'Outfit',sans-serif;font-weight:700;font-size:1.04rem;border:none;cursor:pointer;box-shadow:0 6px 32px rgba(99,102,241,.5);transition:transform .3s,box-shadow .3s;animation:pulse 2s ease-in-out infinite,gradFlow 4s ease infinite;}
    .yes-btn:hover{transform:translateY(-5px) scale(1.06);box-shadow:0 16px 50px rgba(99,102,241,.68);animation:gradFlow 4s ease infinite;}
    .confetti-p{position:fixed;width:9px;height:9px;border-radius:2px;animation:confetti 3.5s ease-in forwards;pointer-events:none;z-index:10002;}
    .star{position:absolute;border-radius:50%;background:white;animation:twinkle var(--dur,3s) ease-in-out infinite;animation-delay:var(--del,0s);}

    /* ── Sparkle particles ── */
    .sparkle{position:absolute;pointer-events:none;animation:sparkle var(--dur,1.5s) ease-in-out var(--del,0s) infinite;}
    .sparkle::before,.sparkle::after{content:'✦';position:absolute;color:var(--indigo-lt);font-size:var(--sz,.8rem);opacity:0;animation:sparkle var(--dur,1.5s) ease-in-out var(--del,0s) infinite;}
    .sparkle::after{animation-delay:calc(var(--del,0s) + .4s);color:var(--teal);}

    /* ── Aurora hero bg ── */
    .aurora-hero{
      position:absolute;inset:0;
      background:linear-gradient(135deg,rgba(99,102,241,.08) 0%,rgba(45,212,191,.05) 40%,rgba(251,146,60,.04) 70%,rgba(99,102,241,.07) 100%);
      background-size:400% 400%;
      animation:aurora 12s ease infinite;
      pointer-events:none;
    }

    /* ── Stat item ── */
    .stat-num{
      font-family:'Cormorant Garamond',serif;font-size:2.4rem;font-weight:700;line-height:1;
      background:linear-gradient(135deg,var(--indigo),var(--teal));
      -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
      animation:countUp .8s ease both;
    }

    /* ── Gradient section divider wave ── */
    .wave-div{
      width:100%;height:60px;
      background:linear-gradient(90deg,transparent,var(--indigo),var(--teal),var(--indigo),transparent);
      background-size:200% 3px;
      background-repeat:no-repeat;
      background-position:0 50%;
      animation:shimmer 3s linear infinite;
      position:relative;
      margin:0 auto;
      max-width:300px;
      height:3px;
      border-radius:4px;
    }

    /* ── Mobile ── */
    @media(max-width:768px){
      section{padding:70px 0;}
      .p-img{width:200px;height:200px;}
      .hide-mob{display:none!important;}
      .mob-col{grid-template-columns:1fr!important;}
      .mob-col2{grid-template-columns:1fr 1fr!important;}
    }

    footer{padding:46px 0;border-top:1px solid var(--border);text-align:center;color:var(--muted);font-size:.82rem;}
  `}</style>
);

/* ═══════════════════════════════════════════════════════════════
   DATA — update all personal info here
═══════════════════════════════════════════════════════════════ */
const D = {
  name:"Arjun Sharma", first:"Arjun",
  designation:"Senior Software Engineer", company:"Google India",
  tagline:"Crafting code by day, seeking a lifelong companion for the beautiful journey ahead.",
  age:29, dob:"15 March 1996", height:"5'11\" (181 cm)", weight:"74 kg",
  complexion:"Wheatish", religion:"Hindu", caste:"Brahmin", gotra:"Bharadwaj",
  city:"Bangalore, Karnataka", native:"Jaipur, Rajasthan",
  marital:"Never Married", manglik:"Non-Manglik",
  phone:"+91 98765 43210", email:"arjun.sharma@email.com",
  whatsapp:"919876543210", calendly:"https://calendly.com", income:"₹ 35–40 LPA",

  about:"I am a grounded, ambitious, and family-oriented individual who values meaningful relationships above all. While I thrive in the fast-paced world of technology, I deeply respect our cultural roots and traditions. I believe in building a partnership that is equal, respectful, and full of warmth. Off the keyboard, you'll find me hiking mountain trails, experimenting in the kitchen, or losing myself in a thoughtful novel.",

  traits:["Family-Oriented","Ambitious","Humorous","Adaptable","Empathetic","Creative","Patient","Honest"],

  values:[
    {icon:"🏡",t:"Family First",   d:"Deep respect for parents, elders, and family bonds"},
    {icon:"🌱",t:"Growth Mindset", d:"Continuous learner — personally and professionally"},
    {icon:"🕊️",t:"Inner Harmony",  d:"Peaceful, balanced approach to life and relationships"},
    {icon:"💡",t:"Thoughtful",     d:"Forward-thinking individual rooted in tradition"},
  ],

  career:[
    {yr:"2023 – Present",role:"Senior Software Engineer", org:"Google India, Bangalore", d:"Leading backend infrastructure for Google Pay — serving 150M+ users."},
    {yr:"2020 – 2023",   role:"Software Engineer II",     org:"Flipkart, Bangalore",      d:"Architected high-scale microservices powering the e-commerce checkout flow."},
    {yr:"2018 – 2020",   role:"Junior Developer",         org:"TCS, Pune",                d:"Full-stack banking solutions for Fortune 500 clients."},
  ],

  education:[
    {deg:"B.Tech – Computer Science",inst:"IIT Bombay",                 yr:"2014 – 2018",grade:"8.9 CGPA",icon:"🎓"},
    {deg:"Class XII – CBSE",         inst:"St. Xavier's School, Jaipur",yr:"2014",        grade:"95.6%",  icon:"📚"},
    {deg:"Class X – CBSE",           inst:"St. Xavier's School, Jaipur",yr:"2012",        grade:"96.2%",  icon:"🏆"},
  ],

  family:{
    father:{name:"Rakesh Sharma", occ:"Retired IAS Officer",       note:"Served as District Collector, Rajasthan"},
    mother:{name:"Sunita Sharma", occ:"Homemaker & Social Worker", note:"Runs a local women's empowerment NGO"},
    siblings:[{name:"Priya Sharma",rel:"Elder Sister",occ:"Doctor – AIIMS Delhi",married:true}],
  },

  gallery:[
    {url:"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=900&h=600&fit=crop&crop=face",cap:"Professional Photo"},
    {url:"https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=900&h=600&fit=crop",          cap:"At Google Campus"},
    {url:"https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=900&h=600&fit=crop",          cap:"Hiking in Coorg"},
    {url:"https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=900&h=600&fit=crop",          cap:"Family Celebration"},
    {url:"https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=900&h=600&fit=crop",          cap:"Trip to Ladakh"},
    {url:"https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=900&h=600&fit=crop",          cap:"Casual Day Out"},
  ],

  videoUrl:"https://www.youtube.com/embed/dQw4w9WgXcQ",

  prefs:[
    {l:"Age Range",     v:"25 – 27 years"},{l:"Education",     v:"Graduate or Post-Graduate"},
    {l:"Profession",    v:"Working professional"},{l:"Location",      v:"Open to any city"},
    {l:"Religion",      v:"Hindu"},{l:"Caste",         v:"Open – no bar"},
    {l:"Manglik",       v:"No preference"},{l:"Diet",          v:"Vegetarian preferred"},
    {l:"Family Values", v:"Family-oriented"},{l:"Lifestyle",     v:"Traditional meets modern"},
    {l:"Complexion",    v:"No preference"},{l:"Compatibility",  v:"Emotionally mature"},
  ],

  langs:  ["Hindi","English","Rajasthani","Kannada (basic)"],
  hobbies:["Trekking 🏔️","Chess ♟️","Cooking 🍳","Reading 📖","Photography 📷","Yoga 🧘","Travel ✈️","Music 🎸"],
  diet:"Vegetarian",
  horoscope:{rashi:"Tula (Libra)",nakshatra:"Swati",gotra:"Bharadwaj"},
};

const WA = `https://wa.me/${D.whatsapp}?text=Hello%20${D.first}!%20I%20came%20across%20your%20biodata%20and%20would%20love%20to%20connect.`;

/* ═══════════════════════════════════════════════════════════════
   HOOK — Typewriter effect
═══════════════════════════════════════════════════════════════ */
function useTypewriter(text, speed = 40, delay = 600) {
  const [display, setDisplay] = useState("");
  const [done, setDone] = useState(false);
  useEffect(() => {
    let i = 0;
    const t = setTimeout(() => {
      const iv = setInterval(() => {
        setDisplay(text.slice(0, i + 1));
        i++;
        if (i >= text.length) { clearInterval(iv); setDone(true); }
      }, speed);
      return () => clearInterval(iv);
    }, delay);
    return () => clearTimeout(t);
  }, [text, speed, delay]);
  return { display, done };
}

/* ═══════════════════════════════════════════════════════════════
   HOOK — CountUp number animation
═══════════════════════════════════════════════════════════════ */
function useCountUp(target, duration = 1200, startDelay = 300) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          const start = Date.now();
          const num = parseFloat(target);
          const isNum = !isNaN(num);
          if (!isNum) { setCount(target); return; }
          const iv = setInterval(() => {
            const elapsed = Date.now() - start;
            const progress = Math.min(elapsed / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(ease * num));
            if (progress >= 1) { setCount(num); clearInterval(iv); }
          }, 16);
        }, startDelay);
        obs.unobserve(el);
      }
    }, { threshold: 0.5 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [target, duration, startDelay]);
  return { count, ref };
}

/* ═══════════════════════════════════════════════════════════════
   COMPONENT — Floating sparkle particles
═══════════════════════════════════════════════════════════════ */
function Sparkles({ count = 12 }) {
  const items = Array.from({ length: count }, (_, i) => ({
    id: i,
    top: Math.random() * 100,
    left: Math.random() * 100,
    dur: 1.5 + Math.random() * 2,
    del: Math.random() * 3,
    sz: 0.5 + Math.random() * 0.8,
  }));
  return (
    <>
      {items.map(s => (
        <div key={s.id} style={{
          position: "absolute", top: s.top + "%", left: s.left + "%",
          pointerEvents: "none", zIndex: 0,
          animation: `sparkle ${s.dur}s ease-in-out ${s.del}s infinite`,
          fontSize: s.sz + "rem",
          color: s.id % 2 === 0 ? "rgba(99,102,241,.6)" : "rgba(45,212,191,.5)",
          opacity: 0,
        }}>✦</div>
      ))}
    </>
  );
}

/* ═══════════════════════════════════════════════════════════════
   COMPONENT — Stat with countup
═══════════════════════════════════════════════════════════════ */
function StatItem({ value, label, prefix = "", suffix = "" }) {
  const isNum = !isNaN(parseFloat(value));
  const { count, ref } = useCountUp(isNum ? parseFloat(value) : 0, 1000);
  return (
    <div ref={ref} style={{ textAlign: "center" }}>
      <div className="stat-num">{prefix}{isNum ? count : value}{suffix}</div>
      <div style={{ fontSize: ".68rem", color: "var(--muted)", letterSpacing: ".12em", textTransform: "uppercase", marginTop: 5 }}>{label}</div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   GATE — Funny YES / Runaway NO
═══════════════════════════════════════════════════════════════ */
function Gate({ onEnter }) {
  const [pos,   setPos]  = useState({ x: null, y: null });
  const [tries, setTries] = useState(0);
  const [conf,  setConf]  = useState(false);

  const scramble = useCallback(() => {
    const mg = 80, w = window.innerWidth, h = window.innerHeight, bw = 160, bh = 52;
    let rx, ry;
    do {
      rx = mg + Math.random() * (w - bw - mg * 2);
      ry = mg + Math.random() * (h - bh - mg * 2);
    } while (rx > w / 2 - 160 && rx < w / 2 + 80 && ry > h / 2 - 60 && ry < h / 2 + 60);
    setPos({ x: rx, y: ry }); setTries(t => t + 1);
  }, []);

  useEffect(() => {
    const init = () => setPos({ x: window.innerWidth / 2 + 110, y: window.innerHeight / 2 + 14 });
    init(); window.addEventListener("resize", init);
    return () => window.removeEventListener("resize", init);
  }, []);

  const msgs = ["Oops! Wrong button 😅", "Try harder? 🤭", "Are you really sure? 🥺", "I'm running! 😂", "Catch me if you can! 🏃", "Just click YES already 😤", "Stop chasing me! 😝", "YES button misses you 💔", "I'm too shy 🙈", "Okay you win… but click YES! 🎉"];
  const cColors = ["#818cf8", "#a5b4fc", "#2dd4bf", "#99f6e4", "#fb923c", "#c4b5fd", "#6366f1", "#fdba74"];
  const cItems = Array.from({ length: 50 }, (_, i) => ({
    id: i, color: cColors[i % cColors.length],
    left: Math.random() * 100, delay: Math.random() * 1,
    size: 6 + Math.random() * 12, rot: Math.random() * 360,
  }));
  const petals = Array.from({ length: 18 }, (_, i) => ({
    id: i, emoji: ["🌸", "✨", "💫", "⭐", "🌺"][i % 5],
    left: Math.random() * 100, dur: 4 + Math.random() * 5, del: Math.random() * 5,
  }));

  return (
    <div className="gate">
      <div className="gate-bg" />
      <div className="gate-aurora" />

      {petals.map(p => (
        <div key={p.id} className="petal" style={{ left: p.left + "%", "--dur": p.dur + "s", "--del": p.del + "s" }}>{p.emoji}</div>
      ))}

      {Array.from({ length: 70 }).map((_, i) => (
        <div key={i} className="star" style={{ width: 1 + Math.random() * 2.5 + "px", height: 1 + Math.random() * 2.5 + "px", top: Math.random() * 100 + "%", left: Math.random() * 100 + "%", "--dur": (2 + Math.random() * 3.5) + "s", "--del": (Math.random() * 4) + "s", opacity: .2 }} />
      ))}

      {conf && cItems.map(c => (
        <div key={c.id} className="confetti-p" style={{ background: c.color, left: c.left + "%", top: "-20px", width: c.size + "px", height: c.size + "px", animationDelay: c.delay + "s", transform: `rotate(${c.rot}deg)`, borderRadius: c.id % 3 === 0 ? "50%" : "2px" }} />
      ))}

      <div className="gate-card glass" style={{ borderRadius: 30, animation: "fadeUp .9s ease both" }}>
        <span className="gate-emoji">💍</span>

        <h1 className="gate-title">
          Are you looking for a{" "}
          <span style={{ background: "linear-gradient(135deg,#4338ca,#6366f1,#a5b4fc,#2dd4bf)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundSize: "200% auto", animation: "shimmer 3s linear infinite" }}>
            Son-in-Law
          </span>{" "}
          for your daughter?
        </h1>

        <p className="gate-sub">
          {tries === 0
            ? "A wonderful, family-oriented, well-educated gentleman awaits ✨"
            : tries < 4
              ? msgs[tries] + " — The YES button is right there! 👇"
              : `You've tried ${tries} times! Just say YES 😂`}
        </p>

        <button className="yes-btn" onClick={() => { setConf(true); setTimeout(onEnter, 1600); }}>
          💖 Yes, Absolutely!
        </button>

        <p style={{ marginTop: 16, fontSize: ".76rem", color: "#4a5088", fontWeight: 300 }}>
          Click YES to meet our wonderful candidate →
        </p>
      </div>

      {pos.x !== null && (
        <button className="no-btn" style={{ left: pos.x + "px", top: pos.y + "px" }} onMouseEnter={scramble} onClick={scramble}>
          {tries === 0 ? "🚫 No" : tries < 3 ? "😏 Still No" : tries < 6 ? "🏃 Nope!" : "🙈 Never!"}
        </button>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════════════════════════ */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".sr,.sr-l,.sr-r,.sr-scale");
    const obs = new IntersectionObserver(entries => entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add("vis"); obs.unobserve(e.target); }
    }), { threshold: .08 });
    els.forEach(el => obs.observe(el));
    return () => obs.disconnect();
  });
}

/* ═══════════════════════════════════════════════════════════════
   BIODATA WEBSITE
═══════════════════════════════════════════════════════════════ */
function Website() {
  const [dark,   setDark]   = useState(true);
  const [loaded, setLoaded] = useState(false);
  const [sy,     setSy]     = useState(0);
  const [pct,    setPct]    = useState(0);
  const [mob,    setMob]    = useState(false);
  const [lb,     setLb]     = useState(null);
  const [vid,    setVid]    = useState(false);
  const [ci,     setCi]     = useState(0);
  const timer               = useRef(null);

  useReveal();

  const { display: tagDisplay, done: tagDone } = useTypewriter(D.tagline, 38, 800);

  useEffect(() => { const s = localStorage.getItem("bm3"); if (s) setDark(s === "dark"); }, []);
  const tog = () => setDark(d => { localStorage.setItem("bm3", !d ? "dark" : "light"); return !d; });

  useEffect(() => { const t = setTimeout(() => setLoaded(true), 1500); return () => clearTimeout(t); }, []);

  useEffect(() => {
    const fn = () => {
      setSy(window.scrollY);
      const d = document.documentElement;
      setPct((d.scrollTop || document.body.scrollTop) / (d.scrollHeight - d.clientHeight) * 100);
    };
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  useEffect(() => {
    timer.current = setInterval(() => setCi(i => (i + 1) % D.gallery.length), 3500);
    return () => clearInterval(timer.current);
  }, []);

  const navLinks = ["About", "Career", "Education", "Family", "Gallery", "Preferences", "Contact"];
  const ACC  = dark ? "#818cf8" : "#4f46e5";
  const ACC2 = dark ? "#a5b4fc" : "#6366f1";
  const TEAL = dark ? "#2dd4bf" : "#0d9488";

  return (
    <div className={dark ? "dark" : "light"} style={{ minHeight: "100vh" }}>

      {/* ── Loading ── */}
      <div className={`loading ${loaded ? "gone" : ""}`}>
        <div className="l-ring" />
        <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: "1.55rem", background: "linear-gradient(135deg,#6366f1,#2dd4bf)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: ".22em" }}>
          {D.name.toUpperCase()}
        </div>
        <div style={{ fontSize: ".74rem", color: "var(--muted)", letterSpacing: ".2em" }}>MARRIAGE BIODATA</div>
      </div>

      {/* ── Progress ── */}
      <div className="prog" style={{ width: `${pct}%` }} />

      {/* ── WhatsApp Float ── */}
      <a href={WA} target="_blank" rel="noreferrer" className="wa" title="WhatsApp">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
          <path d="M12 0C5.373 0 0 5.373 0 12c0 2.098.547 4.071 1.5 5.793L0 24l6.35-1.484A11.948 11.948 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.885 0-3.651-.511-5.173-1.395l-.37-.22-3.767.881.903-3.659-.242-.387A10.007 10.007 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z" />
        </svg>
      </a>

      {/* ── NAV ── */}
      <nav className={sy > 60 ? "shrunk" : ""}>
        <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }}>
          <span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: "1.5rem", fontWeight: 700, background: "linear-gradient(135deg,var(--indigo),var(--teal))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: ".06em" }}>
            A<span style={{ opacity: .4 }}>.</span>S<span style={{ opacity: .4 }}>.</span>
          </span>
          <div className="hide-mob" style={{ display: "flex", gap: 26 }}>
            {navLinks.map(l => <a key={l} href={`#${l.toLowerCase()}`} className="nav-link">{l}</a>)}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={tog} className="tog"><div className="tog-k">{dark ? "🌙" : "☀️"}</div></button>
            <button onClick={() => setMob(m => !m)} style={{ background: "none", border: "1px solid var(--border)", borderRadius: 8, color: "var(--text)", cursor: "pointer", padding: "6px 10px", display: "none" }} className="hbg">{mob ? "✕" : "☰"}</button>
          </div>
        </div>
        {mob && (
          <div style={{ background: "var(--bg2)", borderTop: "1px solid var(--border)", padding: "18px 28px", display: "flex", flexDirection: "column", gap: 16 }}>
            {navLinks.map(l => <a key={l} href={`#${l.toLowerCase()}`} className="nav-link" onClick={() => setMob(false)}>{l}</a>)}
          </div>
        )}
      </nav>
      <style>{`.hbg{display:none!important;}@media(max-width:768px){.hbg{display:block!important;}}`}</style>

      {/* ════════════════════ HERO ════════════════════ */}
      <section id="about" style={{ minHeight: "100vh", display: "flex", alignItems: "center", padding: "80px 0 60px" }}>
        <div className="bg-dots" />
        <div className="aurora-hero" />
        <Sparkles count={16} />

        {/* Morphing blobs */}
        <div style={{ position: "absolute", width: 620, height: 620, top: -130, left: -130, borderRadius: "60% 40% 30% 70%/60% 30% 70% 40%", background: "radial-gradient(circle,var(--orb1),transparent 70%)", animation: "orb1 12s ease-in-out infinite, morphBlob 18s ease-in-out infinite", pointerEvents: "none" }} />
        <div style={{ position: "absolute", width: 500, height: 500, bottom: -100, right: -100, borderRadius: "30% 60% 70% 40%/50% 60% 30% 60%", background: "radial-gradient(circle,var(--orb2),transparent 70%)", animation: "orb2 14s ease-in-out infinite, morphBlob 22s ease-in-out infinite reverse", pointerEvents: "none" }} />
        <div style={{ position: "absolute", width: 300, height: 300, top: "40%", left: "40%", borderRadius: "50%", background: "radial-gradient(circle,rgba(251,146,60,.04),transparent 70%)", animation: "orb3 9s ease-in-out infinite", pointerEvents: "none" }} />

        <div className="container" style={{ position: "relative", zIndex: 1, width: "100%" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 64, alignItems: "center" }} className="mob-col">

            {/* Left */}
            <div style={{ animation: "fadeLeft .95s ease both" }}>
              <span className="tag i" style={{ marginBottom: 22, display: "inline-block", animation: "fadeUp .6s ease both" }}>💍 Marriage Biodata 2024</span>
              <h1 style={{ fontSize: "clamp(2.8rem,6.5vw,5.4rem)", fontWeight: 700, lineHeight: 1.04, fontStyle: "italic", marginBottom: 14 }}>
                <span className="indigo-txt">{D.name}</span>
              </h1>
              <div style={{ fontSize: ".86rem", color: "var(--muted)", letterSpacing: ".22em", textTransform: "uppercase", marginBottom: 20, fontWeight: 300 }}>
                {D.designation} · {D.company}
              </div>
              {/* Typewriter tagline */}
              <p style={{ fontSize: "1.05rem", color: "var(--muted)", lineHeight: 1.88, maxWidth: 500, fontWeight: 300, marginBottom: 36, minHeight: "3.5em", borderRight: tagDone ? "none" : "2px solid var(--acc)", paddingRight: 4, animation: tagDone ? "none" : "blinkCursor .7s ease-in-out infinite" }}>
                {tagDisplay}
              </p>

              <div style={{ display: "flex", flexWrap: "wrap", gap: 13, marginBottom: 48 }}>
                <a href={WA} target="_blank" rel="noreferrer" className="btn-primary">💬 Chat on WhatsApp</a>
                <a href={D.calendly} target="_blank" rel="noreferrer" className="btn-out"><span>📅 Schedule Meeting</span></a>
              </div>

              {/* Stats with count-up */}
              <div style={{ display: "flex", gap: 40, flexWrap: "wrap" }}>
                <StatItem value={29} label="Years Old" />
                <div style={{ textAlign: "center" }}>
                  <div className="stat-num" style={{ fontSize: "1.6rem" }}>IIT</div>
                  <div style={{ fontSize: ".68rem", color: "var(--muted)", letterSpacing: ".12em", textTransform: "uppercase", marginTop: 5 }}>Bombay</div>
                </div>
                <StatItem value={6} label="Yrs Experience" suffix="+" />
                <div style={{ textAlign: "center" }}>
                  <div className="stat-num" style={{ fontSize: "1.6rem" }}>G</div>
                  <div style={{ fontSize: ".68rem", color: "var(--muted)", letterSpacing: ".12em", textTransform: "uppercase", marginTop: 5 }}>Google</div>
                </div>
              </div>
            </div>

            {/* Right – Photo */}
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 26, animation: "fadeRight .95s ease .15s both" }}>
              <div className="p-wrap" style={{ animation: "float 6s ease-in-out infinite" }}>
                <div className="r1" /><div className="r2" />
                <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=600&fit=crop&crop=face" alt={D.name} className="p-img" />
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 9, justifyContent: "center", maxWidth: 340 }}>
                {[["📍", D.city], ["🙏", `${D.religion} · ${D.caste}`], ["💒", "Non-Manglik"], ["💼", D.income]].map(([ic, v]) => (
                  <span key={v} className="tag i" style={{ fontSize: ".74rem", animation: "fadeUp .6s ease both" }}>{ic} {v}</span>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ════════════════════ ABOUT ════════════════════ */}
      <section style={{ background: "var(--bg2)" }}>
        <div className="container">
          <p className="sec-label sr">The Person</p>
          <h2 className="sec-title sr">About Me</h2>
          <div className="divider sr" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 52, alignItems: "start" }} className="mob-col">
            <div className="sr-l">
              <p style={{ fontSize: "1.02rem", lineHeight: 2, color: "var(--muted)", fontWeight: 300, marginBottom: 30 }}>{D.about}</p>
              <div>
                <div style={{ fontSize: ".68rem", letterSpacing: ".18em", textTransform: "uppercase", color: "var(--muted)", marginBottom: 12 }}>Personality Traits</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 9 }}>
                  {D.traits.map((t, i) => (
                    <span key={t} className="tag i" style={{ transitionDelay: i * .05 + "s", cursor: "default" }}>{t}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="sr-r" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {D.values.map((v, i) => (
                <div key={i} className="card sr-scale" style={{ textAlign: "center", transitionDelay: i * .1 + "s" }}>
                  <div style={{ fontSize: "1.9rem", marginBottom: 11 }}>{v.icon}</div>
                  <h4 style={{ fontSize: ".98rem", marginBottom: 7, color: ACC }}>{v.t}</h4>
                  <p style={{ fontSize: ".78rem", color: "var(--muted)", lineHeight: 1.65, fontWeight: 300 }}>{v.d}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Details table */}
          <div className="card sr" style={{ maxWidth: 700, margin: "58px auto 0" }}>
            <h3 style={{ marginBottom: 24, fontSize: "1.45rem" }}>Personal Details</h3>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px 32px" }} className="mob-col2">
              {[["Full Name", D.name], ["Date of Birth", D.dob], ["Age", `${D.age} years`], ["Height / Weight", `${D.height} / ${D.weight}`], ["Complexion", D.complexion], ["Religion / Caste", `${D.religion} / ${D.caste}`], ["Gotra", D.gotra], ["Native Place", D.native], ["Marital Status", D.marital], ["Manglik", D.manglik]].map(([k, v]) => (
                <div key={k} style={{ borderBottom: "1px solid var(--border)", paddingBottom: 11 }}>
                  <div style={{ fontSize: ".66rem", letterSpacing: ".12em", textTransform: "uppercase", color: "var(--muted)", marginBottom: 3 }}>{k}</div>
                  <div style={{ fontSize: ".92rem", color: "var(--head)", fontWeight: 400 }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ════════════════════ CAREER ════════════════════ */}
      <section id="career">
        <div className="bg-dots" /><div className="container" style={{ position: "relative", zIndex: 1 }}>
          <p className="sec-label sr">Professional</p>
          <h2 className="sec-title sr">Career Journey</h2>
          <div className="divider sr" />
          <div style={{ maxWidth: 700, margin: "0 auto" }}>
            <div className="tl">
              {D.career.map((item, i) => (
                <div key={i} className="tl-item sr" style={{ transitionDelay: `${i * .14}s` }}>
                  <div className="tl-dot"><div className="tl-in" /></div>
                  <div className="card">
                    <div style={{ fontSize: ".7rem", color: ACC, letterSpacing: ".12em", textTransform: "uppercase", marginBottom: 5 }}>{item.yr}</div>
                    <h4 style={{ fontSize: "1.16rem", marginBottom: 4 }}>{item.role}</h4>
                    <div style={{ color: TEAL, fontSize: ".86rem", marginBottom: 9, fontStyle: "italic" }}>{item.org}</div>
                    <p style={{ fontSize: ".84rem", color: "var(--muted)", lineHeight: 1.75, fontWeight: 300 }}>{item.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ════════════════════ EDUCATION ════════════════════ */}
      <section id="education" style={{ background: "var(--bg2)" }}>
        <div className="container">
          <p className="sec-label sr">Academic</p>
          <h2 className="sec-title sr">Education</h2>
          <div className="divider sr" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(275px,1fr))", gap: 22 }}>
            {D.education.map((e, i) => (
              <div key={i} className="card sr-scale" style={{ textAlign: "center", transitionDelay: `${i * .11}s` }}>
                <div style={{ fontSize: "3rem", marginBottom: 14 }}>{e.icon}</div>
                <h4 style={{ fontSize: "1.06rem", color: ACC, marginBottom: 9 }}>{e.deg}</h4>
                <div style={{ fontSize: ".94rem", color: "var(--head)", fontWeight: 500, marginBottom: 5 }}>{e.inst}</div>
                <div style={{ fontSize: ".78rem", color: "var(--muted)", marginBottom: 14 }}>{e.yr}</div>
                <span className="tag i" style={{ fontWeight: 600 }}>{e.grade}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ════════════════════ FAMILY ════════════════════ */}
      <section id="family">
        <div className="container">
          <p className="sec-label sr">Background</p>
          <h2 className="sec-title sr">Family</h2>
          <div className="divider sr" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(250px,1fr))", gap: 22, maxWidth: 880, margin: "0 auto" }}>
            {[{ emoji: "👨", label: "Father", ...D.family.father }, { emoji: "👩", label: "Mother", ...D.family.mother }, ...D.family.siblings.map(s => ({ emoji: "👩‍⚕️", label: s.rel, name: s.name, occ: s.occ, note: s.married ? "Happily Married" : "Unmarried" }))].map((m, i) => (
              <div key={i} className="card sr" style={{ textAlign: "center", transitionDelay: `${i * .11}s` }}>
                <div style={{ fontSize: "2.5rem", marginBottom: 14 }}>{m.emoji}</div>
                <div style={{ fontSize: ".65rem", letterSpacing: ".18em", textTransform: "uppercase", color: "var(--muted)", marginBottom: 7 }}>{m.label}</div>
                <h4 style={{ fontSize: "1.1rem", marginBottom: 5 }}>{m.name}</h4>
                <div style={{ color: TEAL, fontSize: ".84rem", marginBottom: 9 }}>{m.occ}</div>
                <span className="tag">{m.note}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ════════════════════ GALLERY ════════════════════ */}
      <section id="gallery" style={{ background: "var(--bg2)" }}>
        <div className="container">
          <p className="sec-label sr">Moments</p>
          <h2 className="sec-title sr">Photo Gallery</h2>
          <div className="divider sr" />

          {/* Carousel */}
          <div className="gal sr" onClick={() => setLb(D.gallery[ci])} style={{ marginBottom: 16 }}>
            {D.gallery.map((g, i) => (
              <div key={i} className={`gal-s ${i === ci ? "on" : ""}`} style={{ backgroundImage: `url(${g.url})` }} />
            ))}
            <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "38px 22px 18px", background: "linear-gradient(to top,rgba(6,11,24,.8),transparent)", zIndex: 2 }}>
              <span style={{ color: "rgba(255,255,255,.8)", fontSize: ".86rem", letterSpacing: ".1em" }}>{D.gallery[ci].cap} · Click to enlarge</span>
            </div>
            {[-1, 1].map(d => (
              <button key={d} onClick={e => { e.stopPropagation(); setCi(i => (i + d + D.gallery.length) % D.gallery.length); }}
                style={{ position: "absolute", [d === -1 ? "left" : "right"]: 14, top: "50%", transform: "translateY(-50%)", background: "rgba(6,11,24,.6)", border: "1px solid rgba(99,102,241,.3)", color: ACC, width: 42, height: 42, borderRadius: "50%", cursor: "pointer", fontSize: "1rem", zIndex: 3, display: "flex", alignItems: "center", justifyContent: "center", transition: "all .3s" }}>
                {d === -1 ? "←" : "→"}
              </button>
            ))}
            <div style={{ position: "absolute", bottom: 48, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 7, zIndex: 3 }}>
              {D.gallery.map((_, i) => (
                <button key={i} onClick={e => { e.stopPropagation(); setCi(i); }}
                  style={{ width: i === ci ? 26 : 7, height: 7, borderRadius: 50, border: "none", background: i === ci ? "var(--indigo)" : "rgba(255,255,255,.3)", cursor: "pointer", transition: "all .4s cubic-bezier(.4,0,.2,1)", padding: 0, boxShadow: i === ci ? "0 0 12px rgba(99,102,241,.6)" : "none" }} />
              ))}
            </div>
          </div>

          {/* Thumbs */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(135px,1fr))", gap: 11, marginBottom: 46 }}>
            {D.gallery.map((g, i) => (
              <div key={i} className="sr" onClick={() => setLb(g)}
                style={{ aspectRatio: "1", backgroundImage: `url(${g.url})`, backgroundSize: "cover", backgroundPosition: "center", borderRadius: 13, cursor: "pointer", border: `2px solid ${i === ci ? "var(--indigo)" : "transparent"}`, boxShadow: i === ci ? "0 0 22px var(--glow)" : "none", transition: "all .35s", transitionDelay: `${i * .05}s` }}
                onMouseEnter={e => e.currentTarget.style.transform = "scale(1.07)"}
                onMouseLeave={e => e.currentTarget.style.transform = "scale(1)"} />
            ))}
          </div>

          {/* Video */}
          <div className="sr" style={{ textAlign: "center" }}>
            <button className="btn-primary" onClick={() => setVid(true)} style={{ fontSize: ".97rem" }}>🎬 Watch Video Introduction</button>
          </div>
        </div>
      </section>

      {/* ════════════════════ PREFERENCES ════════════════════ */}
      <section id="preferences">
        <div className="bg-dots" /><div className="container" style={{ position: "relative", zIndex: 1 }}>
          <Sparkles count={8} />
          <p className="sec-label sr">Expectations</p>
          <h2 className="sec-title sr">Partner Preferences</h2>
          <div className="divider sr" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(255px,1fr))", gap: 18 }}>
            {D.prefs.map((p, i) => (
              <div key={i} className="card sr" style={{ display: "flex", alignItems: "center", gap: 16, transitionDelay: `${i * .05}s` }}>
                <div style={{ width: 44, height: 44, borderRadius: "50%", background: "rgba(99,102,241,.09)", border: "1px solid rgba(99,102,241,.25)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <div style={{ width: 13, height: 13, borderRadius: "50%", background: `linear-gradient(135deg,${ACC},${TEAL})` }} />
                </div>
                <div>
                  <div style={{ fontSize: ".66rem", color: "var(--muted)", letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 3 }}>{p.l}</div>
                  <div style={{ fontSize: ".92rem", color: "var(--head)", fontWeight: 500 }}>{p.v}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ════════════════════ ADDITIONAL ════════════════════ */}
      <section style={{ background: "var(--bg2)" }}>
        <div className="container">
          <p className="sec-label sr">More About</p>
          <h2 className="sec-title sr">Additional Details</h2>
          <div className="divider sr" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(248px,1fr))", gap: 22 }}>
            <div className="card sr">
              <h4 style={{ color: ACC, marginBottom: 16 }}>🌐 Languages</h4>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {D.langs.map(l => <span key={l} className="tag i">{l}</span>)}
              </div>
            </div>
            <div className="card sr" style={{ transitionDelay: ".1s" }}>
              <h4 style={{ color: ACC, marginBottom: 16 }}>🎯 Hobbies & Interests</h4>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {D.hobbies.map(h => <span key={h} className="tag t">{h}</span>)}
              </div>
            </div>
            <div className="card sr" style={{ transitionDelay: ".2s" }}>
              <h4 style={{ color: ACC, marginBottom: 16 }}>🍃 Lifestyle</h4>
              {[["Diet", D.diet], ["Smoking", "Non-Smoker"], ["Alcohol", "Non-Drinker"], ["Fitness", "Daily Yoga & Gym"]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid var(--border)", padding: "9px 0" }}>
                  <span style={{ fontSize: ".78rem", color: "var(--muted)" }}>{k}</span>
                  <span style={{ fontSize: ".86rem", color: "var(--head)", fontWeight: 500 }}>{v}</span>
                </div>
              ))}
            </div>
            <div className="card sr" style={{ transitionDelay: ".3s" }}>
              <h4 style={{ color: ACC, marginBottom: 16 }}>⭐ Horoscope & Income</h4>
              {[["Rashi", D.horoscope.rashi], ["Nakshatra", D.horoscope.nakshatra], ["Gotra", D.horoscope.gotra], ["Annual Income", D.income]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid var(--border)", padding: "9px 0" }}>
                  <span style={{ fontSize: ".78rem", color: "var(--muted)" }}>{k}</span>
                  <span style={{ fontSize: ".86rem", color: TEAL, fontWeight: 500 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ════════════════════ CONTACT ════════════════════ */}
      <section id="contact">
        <div className="container">
          <p className="sec-label sr">Reach Out</p>
          <h2 className="sec-title sr">Let's Connect</h2>
          <div className="divider sr" />
          <div style={{ maxWidth: 680, margin: "0 auto", textAlign: "center" }} className="sr">
            <div className="card" style={{ padding: "54px 42px", position: "relative", overflow: "hidden", animation: "borderGlow 4s ease-in-out infinite" }}>
              <div className="cd ctl" /><div className="cd ctr" /><div className="cd cbl" /><div className="cd cbr" />

              {/* Aurora background inside card */}
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg,rgba(99,102,241,.05),rgba(45,212,191,.03),rgba(251,146,60,.02))", backgroundSize: "300% 300%", animation: "aurora 8s ease infinite", pointerEvents: "none" }} />

              <div style={{ position: "relative", zIndex: 1 }}>
                <div style={{ fontSize: "3.4rem", marginBottom: 14 }}><span className="heart">💙</span></div>
                <h3 style={{ fontSize: "1.95rem", marginBottom: 12 }}>
                  Interested in connecting with{" "}
                  <span className="indigo-txt">{D.first}</span>?
                </h3>
                <p style={{ color: "var(--muted)", marginBottom: 36, lineHeight: 1.86, fontWeight: 300 }}>
                  We'd be delighted to hear from you. Please reach out via any of the options below and we will respond promptly.
                </p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "center", marginBottom: 38 }}>
                  <a href={WA} target="_blank" rel="noreferrer" className="btn-primary">💬 WhatsApp</a>
                  <a href={D.calendly} target="_blank" rel="noreferrer" className="btn-out"><span>📅 Schedule</span></a>
                  <a href={`mailto:${D.email}`} className="btn-out"><span>📧 Email</span></a>
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 22, justifyContent: "center", color: "var(--muted)", fontSize: ".84rem" }}>
                  {[["📞", D.phone], ["📧", D.email], ["📍", D.city]].map(([ic, v]) => (
                    <span key={v} style={{ display: "flex", alignItems: "center", gap: 5 }}>{ic} {v}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <div className="container">
          <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: "1.9rem", background: "linear-gradient(135deg,var(--indigo),var(--teal))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", marginBottom: 8 }}>{D.name}</div>
          <p style={{ marginBottom: 12, fontWeight: 300 }}>Made with <span className="heart" style={{ fontSize: ".95rem" }}>💙</span> for a beautiful beginning</p>
          <p style={{ opacity: .4, fontSize: ".72rem" }}>© {new Date().getFullYear()} {D.name} · Marriage Biodata · All Rights Reserved</p>
        </div>
      </footer>

      {/* Lightbox */}
      {lb && (
        <div className="lb" onClick={() => setLb(null)}>
          <div style={{ position: "relative" }} onClick={e => e.stopPropagation()}>
            <img src={lb.url} alt={lb.cap} className="lb-i" />
            <p style={{ textAlign: "center", color: "rgba(255,255,255,.6)", marginTop: 10, fontSize: ".86rem" }}>{lb.cap}</p>
            <button onClick={() => setLb(null)} style={{ position: "absolute", top: -13, right: -13, width: 34, height: 34, borderRadius: "50%", background: "linear-gradient(135deg,var(--indigo),var(--teal))", border: "none", cursor: "pointer", color: "#fff", fontSize: ".95rem", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 16px rgba(99,102,241,.4)" }}>✕</button>
          </div>
        </div>
      )}

      {/* Video modal */}
      {vid && (
        <div className="mo" onClick={() => setVid(false)}>
          <div className="mo-box" onClick={e => e.stopPropagation()}>
            <div className="card">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                <h3 style={{ color: ACC, fontSize: "1.15rem" }}>🎬 Video Introduction — {D.name}</h3>
                <button onClick={() => setVid(false)} style={{ background: "none", border: "1px solid var(--border)", color: "var(--text)", padding: "5px 14px", borderRadius: 50, cursor: "pointer", fontSize: ".8rem", transition: "all .2s" }}>✕ Close</button>
              </div>
              <div style={{ aspectRatio: "16/9", background: "#000", borderRadius: 13, overflow: "hidden" }}>
                <iframe src={D.videoUrl + "?autoplay=1"} style={{ width: "100%", height: "100%", border: "none" }} allow="autoplay;fullscreen" title="Video Intro" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ROOT
═══════════════════════════════════════════════════════════════ */
export default function App() {
  const [entered, setEntered] = useState(false);
  const [show,    setShow]    = useState(false);
  const go = () => { setEntered(true); setTimeout(() => setShow(true), 400); };
  return (
    <>
      <GlobalStyle />
      {!show && (
        <div style={{ opacity: entered ? 0 : 1, transition: "opacity .6s ease", pointerEvents: entered ? "none" : "auto" }}>
          <Gate onEnter={go} />
        </div>
      )}
      {show && (
        <div style={{ animation: "fadeIn .8s ease both" }}>
          <Website />
        </div>
      )}
    </>
  );
}
