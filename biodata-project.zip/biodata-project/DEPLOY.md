# 🚀 Marriage Biodata — Deployment Guide

## 📁 Project Structure
```
biodata-project/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx
    └── App.jsx        ← All your content & styles
```

---

## 🛠️ Step 1 — Local Setup (Test Before Deploying)

### Install Node.js (if not installed)
Download from: https://nodejs.org (choose LTS version)

### Install & Run Locally
```bash
# 1. Open terminal/command prompt in the project folder
cd biodata-project

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# 4. Open browser at: http://localhost:5173
```

---

## 🌐 Option A — Deploy on VERCEL (Recommended — Free & Fastest)

### Method 1: Via GitHub (Best way)

**Step 1:** Create a free account at https://github.com

**Step 2:** Create a new repository named `marriage-biodata`

**Step 3:** Push your project:
```bash
cd biodata-project
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/marriage-biodata.git
git push -u origin main
```

**Step 4:** Go to https://vercel.com and sign up (use your GitHub account)

**Step 5:** Click **"Add New Project"** → Import your `marriage-biodata` repo

**Step 6:** Settings (Vercel auto-detects Vite — just confirm):
- Framework Preset: **Vite**
- Build Command: `npm run build`
- Output Directory: `dist`

**Step 7:** Click **"Deploy"** — Done! 🎉

Your site will be live at: `https://marriage-biodata.vercel.app` (or similar)

---

### Method 2: Via Vercel CLI (Direct — No GitHub needed)

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy from project folder
cd biodata-project
vercel

# Follow the prompts:
# - Set up and deploy? Y
# - Which scope? (select your account)
# - Link to existing project? N
# - Project name: marriage-biodata
# - Directory: ./
# - Build command: npm run build
# - Output dir: dist

# Your URL will be shown at the end!
```

---

## 🌐 Option B — Deploy on RENDER (Free Tier Available)

**Step 1:** Push to GitHub (same as Vercel Step 1-3 above)

**Step 2:** Go to https://render.com → Sign up

**Step 3:** Click **"New"** → **"Static Site"**

**Step 4:** Connect your GitHub repo

**Step 5:** Configure:
| Setting | Value |
|---------|-------|
| Name | `marriage-biodata` |
| Branch | `main` |
| Build Command | `npm run build` |
| Publish Directory | `dist` |

**Step 6:** Click **"Create Static Site"**

Your site will be live at: `https://marriage-biodata.onrender.com`

---

## 🌐 Option C — Deploy on Netlify (Also Free)

**Step 1:** Build the project locally:
```bash
cd biodata-project
npm install
npm run build
```
This creates a `dist/` folder.

**Step 2:** Go to https://netlify.com → Sign up

**Step 3:** Drag and drop the `dist/` folder onto the Netlify dashboard

That's it! Instant deployment with a random URL like `https://amazing-koala-123.netlify.app`

---

## ✏️ Customizing Your Biodata

All personal data is in **`src/App.jsx`** — look for the `const D = {` block near the top.

### Change personal info:
```jsx
const D = {
  name: "Your Name Here",
  first: "Your First Name",
  designation: "Your Job Title",
  company: "Your Company",
  age: 25,
  // ... etc
}
```

### Change profile photo:
```jsx
<img src="YOUR_PHOTO_URL_HERE" alt={D.name} className="p-img" />
```
> Tip: Upload your photo to https://imgbb.com or https://cloudinary.com and paste the URL

### Change gallery photos:
```jsx
gallery:[
  {url:"YOUR_PHOTO_URL", cap:"Caption"},
  // add more...
],
```

### Change WhatsApp number:
```jsx
whatsapp: "919876543210",  // Country code + number, no spaces
```

---

## 🔄 After Making Changes — Redeploy

If using **Vercel with GitHub**:
```bash
git add .
git commit -m "Updated biodata"
git push
```
Vercel auto-deploys on every push! ✅

If using **Vercel CLI**:
```bash
vercel --prod
```

---

## 🎨 Color Palette Used

| Token | Color | Usage |
|-------|-------|-------|
| Indigo | `#6366f1` | Primary accent, buttons |
| Indigo Light | `#a5b4fc` | Highlights, tags |
| Teal | `#2dd4bf` | Secondary accent |
| Coral | `#fb923c` | Warm touches |
| Deep Navy | `#060b18` | Dark background |

---

## ❓ Need Help?

Common issues:
- **`npm: command not found`** → Install Node.js from nodejs.org
- **`vite: not found`** → Run `npm install` first
- **Build fails** → Check you're in the `biodata-project/` folder

---

*Made with 💙 — Ready to deploy in minutes!*
